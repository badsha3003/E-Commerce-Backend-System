﻿using CURDAPI.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace TokenBasedAuth.Models
{
    [Table("UserTokenTbl")]
    public class UserToken
    {
        [Key]
        public Int64 UserTokenID { get; set; }
     
        [ForeignKey("Users")]
        public Int64 UserID { get; set; }
        
        public string TokenNo { get; set; }
        public virtual Users Users { get; set; }


    }
}

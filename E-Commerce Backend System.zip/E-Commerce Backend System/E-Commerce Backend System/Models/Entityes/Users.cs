﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using TokenBasedAuth.Models;

namespace CURDAPI.Models
{
    [Table("UserTbl")]
    public class Users
    {
        [Key]
        public Int64 UserID { get; set; }
        public string UserName { get; set; }
       
        public string EmailID { get; set; }
       
        public string Password { get; set; }
        public virtual List<UserToken> Tokens { get; set; }
       

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TokenBasedAuth.ViewModels
{
    public class LoginVM
    {
        [Required(ErrorMessage ="Email ID Required")]
        public string EmailID { get; set; }
        [Required(ErrorMessage ="Password Required")]
        public string Password { get; set; }
    }
}

﻿using E_Commerce_Backend_System.Models.Data;
using E_Commerce_Backend_System.Models.Entityes;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Stripe;

namespace E_Commerce_Backend_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
       AppDbContext context;

        public ProductsController(AppDbContext context)
        {
            this.context = context;
        }
        [HttpGet("GetProduct")]
        public IActionResult GetProduct()
        {
            var res = this.context.Products.ToList();
            if (res == null)
                return NotFound();

            return Ok(res);
        }

        [HttpPost("AddProduct")]
        public IActionResult Createproduct(Models.Entityes.Product rec)
        {
            if (rec == null)
                return BadRequest();

            this.context.Products.Add(rec);
            this.context.SaveChanges();
            return Ok("Product Saved!");
        }

        [HttpPut("UpdateProduct")]
        public IActionResult UpdateProduct(Models.Entityes.Product rec)
        {
            if (rec == null)
                return BadRequest();
            this.context.Entry(rec).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            this.context.SaveChanges();

            return Ok("Product Updated!");
        }

        [HttpDelete("DeleteProduct/{id}")]
        public IActionResult DeleteProduct(Int64 id)
        {
            if (id == 0)
                return BadRequest();

            var rec = this.context.Products.Find(id);
            if (rec == null)
                return NotFound();

            this.context.Products.Remove(rec);
            this.context.SaveChanges();

            return Ok("Product Deleted!");

        }


    }
}

﻿using CURDAPI.Models;
using E_Commerce_Backend_System.Models.Data;
using E_Commerce_Backend_System.Models.Entityes;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TokenBasedAuth.Models;
using TokenBasedAuth.ViewModels;

namespace E_Commerce_Backend_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
         AppDbContext context;


        public UsersController(AppDbContext context)
        {
            this.context=context;
          
        }


        [HttpPost("Register")]
        public IActionResult Register(Users rec)
        {
            if (rec == null)
                return BadRequest();

            if (ModelState.IsValid)
            {
                this.context.Users.Add(rec);
                this.context.SaveChanges();
                return Ok("Registered");
            }

            return BadRequest(ModelState);
        }

        [HttpGet("LogOut")]
        public IActionResult Logout(string token)
        {
            var oltoken = context.UserTokens.SingleOrDefault(p => p.TokenNo == token);
            if (oltoken != null)
            {
                context.UserTokens.Remove(oltoken);
                context.SaveChanges();
                return Ok("Logged Out");
            }
            return NotFound();
        }

        [HttpPost("Login")]
        public IActionResult Login(LoginVM rec)
        {
            if (ModelState.IsValid)
            {
                var user = this.context.Users.SingleOrDefault(p => p.EmailID == rec.EmailID && p.Password == rec.Password);
                if (user != null)
                {
                
                    string token = Guid.NewGuid().ToString();

                  
                    var oldtokens = context.UserTokens.Where(p => p.UserID == user.UserID);
                    foreach (var otoken in oldtokens)
                    {
                        context.UserTokens.Remove(otoken);
                    }
                    context.SaveChanges();

                  
                    UserToken ut = new UserToken();
                    ut.TokenNo = token;
                    ut.UserID = user.UserID;
                    context.UserTokens.Add(ut);
                    context.SaveChanges();
                    return Ok(token);

                }

                return BadRequest("Failed");
            }

            return BadRequest(ModelState);

        }
    }
}
